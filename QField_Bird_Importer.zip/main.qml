import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import org.qfield

Item {
    id: plugin
    property var parsed: []
    property string output: "Paste six lines per bird, with blank lines between birds."
    property bool confirmed: false
    property var target: null

    function parseInput(text) {
        var blocks = text.trim().split(/\n\s*\n/);
        var out = [];
        for (var k = 0; k < blocks.length; k++) {
            var lines = blocks[k].split(/\r?\n/).map(function(x){return x.trim();}).filter(function(x){return x.length > 0;});
            if (lines.length !== 6) throw new Error("Record " + (k+1) + " needs exactly 6 lines (has " + lines.length + ").");
            var lat = Number(lines[2]), lon = Number(lines[3]);
            if (!isFinite(lat) || !isFinite(lon) || lat < -90 || lat > 90 || lon < -180 || lon > 180) throw new Error("Invalid coordinates in record " + (k+1));
            if (!/^\d+$/.test(lines[0]) || !/^\d+(\.\d+)?$/.test(lines[1])) throw new Error("Invalid band/frequency in record " + (k+1));
            var dateMatch = /^([A-Za-z]+)\s+(\d{1,2})$/.exec(lines[4]);
            if (!dateMatch || !/^\d\d:\d\d:\d\d$/.test(lines[5])) throw new Error("Invalid date/time in record " + (k+1));
            var months = {January:1,February:2,March:3,April:4,May:5,June:6,July:7,August:8,September:9,October:10,November:11,December:12};
            var m = months[dateMatch[1]], day = Number(dateMatch[2]);
            if (!m || day < 1 || day > 31) throw new Error("Invalid date in record " + (k+1));
            var date = "2026-" + String(m).padStart(2,"0") + "-" + String(day).padStart(2,"0") + "T" + lines[5];
            out.push({band:lines[0],frequency:lines[1],lat:lat,lon:lon,date:date});
        }
        return out;
    }
    function findField(names, wanted) {
        for (var i=0;i<wanted.length;i++) {
            for (var j=0;j<names.length;j++) if (String(names[j]).toLowerCase().replace(/[^a-z0-9]/g,"") === wanted[i]) return j;
        }
        return -1;
    }
    function validateLayer() {
        var layers = qgisProject.mapLayersByName("Telemetry Locations");
        if (!layers || layers.length !== 1) throw new Error("Could not uniquely find Telemetry Locations layer.");
        var layer=layers[0];
        if (!layer.isValid() || !layer.isSpatial()) throw new Error("Target layer is not a valid spatial layer.");
        // Coordinates arrive as WGS84 longitude/latitude. Avoid silently placing them in a projected CRS.
        if (String(layer.crs.authid()).toUpperCase() !== "EPSG:4326") throw new Error("Layer CRS is " + layer.crs.authid() + ", not EPSG:4326. This prototype will not guess a transformation.");
        var names=layer.fields().names();
        var fields={
            band:findField(names,["bandnumber","band"]),
            freq:findField(names,["collarfrequency","frequency","freq"]),
            comments:findField(names,["comments","observer"]),
            lat:findField(names,["latitude","lat"]),
            lon:findField(names,["longitude","lon","long"]),
            time:findField(names,["dateandtime","datetime","timestamp"])
        };
        for (var key in fields) if (fields[key] < 0) throw new Error("Can't match field: " + key + ". Actual fields: " + names.join(", "));
        return {layer:layer,fields:fields,names:names};
    }
    function preview() {
        try {
            parsed=parseInput(input.text);
            target=validateLayer();
            output="Ready to review " + parsed.length + " records in Telemetry Locations (EPSG:4326). First: " + parsed[0].band + " at " + parsed[0].lat + ", " + parsed[0].lon + ".\nEnsure they are not already in the layer before importing.";
            confirmed=false;
        } catch(e) { confirmed=false; parsed=[]; output="PREVIEW BLOCKED: " + e.message; }
    }
    function doImport() {
        if (!confirmed || !target || parsed.length === 0) return;
        var layer=target.layer, f=target.fields;
        try {
            if (!layer.isEditable() && !layer.startEditing()) throw new Error("Layer cannot enter edit mode.");
            for (var i=0;i<parsed.length;i++) {
                var r=parsed[i];
                var geometry=GeometryUtils.createGeometryFromWkt("POINT("+r.lon+" "+r.lat+")");
                var feature=FeatureUtils.createFeature(layer,geometry);
                feature.setAttribute(f.band,r.band);
                feature.setAttribute(f.freq,r.frequency);
                feature.setAttribute(f.comments,"Isaac Boden");
                feature.setAttribute(f.lat,r.lat);
                feature.setAttribute(f.lon,r.lon);
                feature.setAttribute(f.time,r.date);
                if (!layer.addFeature(feature)) throw new Error("Failed to add feature " + (i+1) + ". Changes are still pending; do not sync.");
            }
            if (!layer.commitChanges()) throw new Error("Failed to save layer changes. Review edit errors before syncing.");
            output="Added " + parsed.length + " features. Review on map before QFieldCloud sync.";
            confirmed=false;
        } catch(e) { output="IMPORT ERROR: " + e.message + " — review layer edits. Do not sync until checked."; }
    }
    Component.onCompleted: iface.addItemToPluginsToolbar(button)
    Button {
        id: button
        text: "Bird Import"
        onClicked: panel.open()
    }
    Dialog {
        id: panel
        title: "Quail bulk location importer — TEST"
        parent: Overlay.overlay
        modal: true
        width: Math.min(parent.width-18, 440)
        height: Math.min(parent.height-28, 650)
        x:(parent.width-width)/2
        y:(parent.height-height)/2
        standardButtons: Dialog.Close
        ColumnLayout {
            anchors.fill: parent
            spacing: 8
            Label { text: "Paste six lines per bird; blank line between records."; wrapMode: Text.WordWrap; Layout.fillWidth:true }
            ScrollView {
                Layout.fillWidth: true
                Layout.fillHeight: true
                TextArea { id: input; placeholderText:"2365\n8.793\n34.428201\n-90.013648\nOctober 21\n19:21:00"; wrapMode: TextEdit.NoWrap; selectByMouse: true }
            }
            Label { text: output; wrapMode: Text.WordWrap; Layout.fillWidth:true }
            Button { text: "1. Preview / validate"; Layout.fillWidth:true; onClicked:preview() }
            CheckBox { id: check; text:"I checked these are not already imported"; onCheckedChanged: confirmed=checked && parsed.length > 0 }
            Button { text: "2. Add all to Telemetry Locations"; enabled: confirmed && parsed.length>0; Layout.fillWidth:true; onClicked:doImport() }
        }
    }
}
